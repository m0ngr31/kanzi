# Contributors

I would like to thank and name all the contributors who have donated their precious time and talents to improving this skill:
 - [ausweider](https://github.com/ausweider)
 - [digiltd](https://github.com/digiltd)
 - [ghlynch](https://github.com/ghlynch)
 - [jagsta](https://github.com/jagsta)
 - [jingai](https://github.com/jingai)
 - [kuruoujou](https://github.com/kuruoujou)
 - [m0ngr31](https://github.com/m0ngr31)
 - [mcl22](https://github.com/mcl22)
 - [nemik](https://github.com/nemik)
